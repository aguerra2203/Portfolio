
public class SnakeDriver {

	public static void main(String[] args) {
		SnakeListener game = new SnakeListener(500, 500);

	}

}
