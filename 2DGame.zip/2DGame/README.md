# Snake Game
This is a clone of the basic moving snake game we all know and love.
This game allows players to navigate their snake across the window and collect apples, which grow your snake until you crash

# How To Play
To play this game open the java files in a development environment such as eclipse
Then, use any arrow key to move your snake across the screen
